The following files are required for the lab to work:
- reg_file.sv
- prog123_tb.sv
- ALU.sv
- definitions.sv
- IF.sv
- Ctrl.sv
- TopLevel.sv
- data_mem.sv
- InstROM.sv

All 3 programs worked without issue in the lab demo.

Most files depend on definitions.sv, so compile it first. If any files fail to compile, just compile all again, it's most likely a dependency issue. Place the 9 files in ModelSim, compile all, and then simply run the simulation until it ends (255 us).

The following things have been modified in the test bench:
- All 3 programs have had the displays changed to add underscores every 8 bits for readability.
- Program 1 displays a "correct!" message when the expected and actual bits match.
- The test cases were modified for the sake of the demo (changing it to $random and such)